from PIL import Image
from torchvision import transforms
from torchvision.datasets import CIFAR10
import torch
import torch.nn as nn
import torch.nn.functional as F


class CIFAR10Pair(CIFAR10):
    def __getitem__(self, index):
        img, y = self.data[index], self.targets[index]
        img = Image.fromarray(img)

        x1 = self.transform(img)
        x2 = self.transform(img)

        return x1, x2, y


def NTXentLoss(out1, out2, temperature=0.1):
    """
    Calculates the NT-Xent loss for self-supervised learning.
    """
    batch_size = out1.size(0)
    out = torch.cat([out1, out2], dim=0)

    similarity_matrix = torch.exp(torch.mm(out, out.t().contiguous()) / temperature)
    mask = (torch.ones_like(similarity_matrix) - torch.eye(2 * batch_size, device=similarity_matrix.device)).bool()
    similarity_matrix = similarity_matrix.masked_select(mask).view(2 * batch_size, -1)

    pos_sim = torch.exp(torch.sum(out1 * out2, dim=-1) / temperature)
    pos_sim = torch.cat([pos_sim, pos_sim], dim=0)

    loss = (-torch.log(pos_sim / similarity_matrix.sum(dim=-1))).mean()

    return loss


train_transform = transforms.Compose([
    transforms.RandomResizedCrop(32),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomApply([transforms.ColorJitter(0.4, 0.4, 0.4, 0.1)], p=0.8),
    transforms.RandomGrayscale(p=0.2),
    transforms.ToTensor(),
    transforms.Normalize([0.4914, 0.4822, 0.4465], [0.2023, 0.1994, 0.2010])])

test_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize([0.4914, 0.4822, 0.4465], [0.2023, 0.1994, 0.2010])])
